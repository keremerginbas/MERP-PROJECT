<?php
ob_start();
session_start();
include('araclar/baglanti.php');
include('araclar/canta.php');//Ortak Çanta
//include('araclar/canta2.php');//Kpanel Çanta

$url   = mb_substr($_SERVER['PHP_SELF'],15,100);//Karşılaştırmalarda gerekli dosya adı için alınan yol kesildi Örn: dosya.php
$url2  = $_SERVER['REQUEST_URI'];
$adres = ayar('dizin');

//Kullanıcı Giriş Kontrolü
if(isset($_SESSION['cikis2'])) {$oturumsuresi = $_SESSION['cikis2'];} else {$oturumsuresi=ayar('oturumsuresi');}//Eğer oturum açık kalsın denildi ise kontrolü
giris($_SESSION['isim'],$_SESSION['sifre'],$oturumsuresi,$adres);//Genel oturum kontrolü
$_SESSION['cikis']=time();//En son yapılan işlem zamanı
$_SESSION['sonlink'] = $_SERVER['REQUEST_URI']; //Şifre girişi için son işlem yapılan sayfaya yönlendirme linki.

//Kullanıcı Yetki Kontrolü
//$yetkial = $db->query("SELECT * FROM tb_yetki,tb_yetkisayfa WHERE tb_yetki.sayfa_id = tb_yetkisayfa.sayfa_id && tb_yetki.kullanici_id=".$_SESSION['user']." && tb_yetkisayfa.dosya LIKE '".$url."'");
//if($yetkial->rowCount() == 0) {header("Location:".$adres."pano");}

//Panel Ayarları
$hatarenk 	= ayar('hatarenk');
$listelimit = ayar('verisayi');

$zaman = new zaman;
$seo = new seo;
?>
<!--Bismillahirrahmanirrahim-->
<!doctype html>
<html lang="tr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="<?=$adres?>images/favicon.png" rel="shortcut icon" />

<link href="<?=$adres?>css/font-awesome.min.css" rel="stylesheet"/>
<link href="<?=$adres?>css/jquery.fancybox.css?v=2.1.5" rel="stylesheet" type="text/css" media="screen" />

<link href="<?=$adres?>araclar/datatables/datatables.min.css" rel="stylesheet" type="text/css"/>
<link href="<?=$adres?>css/panel.css" rel="stylesheet" type="text/css"/>
<link href="<?=$adres?>araclar/summernote/summernote-lite.css" rel="stylesheet" type="text/css">
<link href="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css">
<link href="<?=$adres?>araclar/elFinder/css/elfinder.min.css" rel="stylesheet" type="text/css">
<link href="<?=$adres?>araclar/elFinder/css/theme.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?=$adres?>araclar/elFinder/themes/material/css/theme-light.min.css" type="text/css">

<script src="<?=$adres?>js/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="<?=$adres?>js/jquery-ui.js" type="text/javascript"></script>
<script src="<?=$adres?>araclar/summernote/summernote-lite.min.js" type="text/javascript"></script>
<script src="<?=$adres?>araclar/summernote/lang/summernote-tr-TR.js"></script>
<script src="<?=$adres?>araclar/summernote/plugin/elfinder/summernote-ext-elfinder.js"></script>
<script src="<?=$adres?>araclar/datatables/datatables.min.js" type="text/javascript"></script>

<script src="<?=$adres?>araclar/elFinder/js/elfinder.min.js"></script>
<script src="<?=$adres?>araclar/elFinder/js/extras/editors.default.min.js"></script>
<script src="<?=$adres?>araclar/elFinder/js/i18n/elfinder.tr.js" type="text/javascript"></script>

<script src="<?=$adres?>js/jquery.fancybox.js" type="text/javascript"></script>
<script type='text/javascript'>//Popover Javascripti
	jQuery(window).load(function() {
		$('header a').tipsy({fade: true, gravity: 'n'});
		$('.kullanici a[title="Profil"]').tipsy({fade: true, gravity: 's'});
		$('.liste li div a').tipsy({fade: true, gravity: 's'});
		$('.genel-baslik h1 a').tipsy({fade: true, gravity: 'w'});
		$('.islem a').tipsy({fade: true, gravity: 's'});
		$('.mesajsag > a').tipsy({fade: true, gravity: 's'});
		$('.profil-ozet a').tipsy({fade: true, gravity: 's'});
		$('.bilgi').tipsy({fade: true, gravity: 's'});
		$('.datalist-araclar a').tipsy({fade: true, gravity: 's'});
	});
</script>
<!--
<script type="text/javascript">
$(".resimac").fancybox({
	helpers: {
		title : {
			type : 'outside'
		},
	},
	openEffect 	: 'fade',
	closeEffect : 'fade',
	closeSpeed	: 75,
	closeBtn  	: false,
	padding		: 0,
	closeClick 	: true,
});
$(".ikonac").fancybox({
    type   :'iframe',
    width  : 600,
		height : 200,
});
</script>
<script type="text/javascript" charset="utf-8">
	// Documentation for client options:
	// https://github.com/Studio-42/elFinder/wiki/Client-configuration-options
	$(document).ready(function() {
		$('#elfinder').elfinder(
			// 1st Arg - options
			{
				cssAutoLoad : false,               // Disable CSS auto loading
				baseUrl : './',                    // Base URL to css/*, js/*
				url : '<?=$adres?>araclar/elFinder/php/connector.minimal.php',  // connector URL (REQUIRED)
				lang: 'tr',                   // language (OPTIONAL)
				width: '100%',
				height: '94%'
			},
		);
	});
</script>
-->
<title>MERP Öğrenci Yönetim Sistemi</title>
</head>
<body>
<?php @$useral = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id=".$_SESSION['user']."")->fetch(PDO::FETCH_ASSOC);?>
<div class="kasa <?=$useral['kpanel']=='1'?'kucuk':'buyuk'?>">
	<aside>
    	<div class="kullanici">
        	<a href="<?=$adres?>profil" class="kullanici_foto">
            	<div class="kullanici_foto_edit"><i class="fa fa-pencil"></i></div>
                <?=isset($useral['foto'])?'<img src="'.$adres.$useral['foto'].'"/>':''?>
                <i class="fa fa-user fa-lg"></i>
            </a>
            <a href="<?=$adres?>profil" title="Profil" class="kullanici_adi"><?=$_SESSION['adi']?></a>
            <?=$useral['tip']=='1'?'<div class="kullanici_yetki">Akdemisyen</div>':'<div class="kullanici_yetki">Öğrenci</div>'?>
        </div>
    	<nav>
          <?php if($useral['tip']=='1') { ?>
          <ul id="accordion">
            <li><a class="link" href="<?=$adres?>pano"><i class="fa fa-dashcube"></i><span>Pano</span></a></li>
            <li><div class="link"><i class="fa fa-file-text"></i><span>Dersler<i class="fa fa-chevron-right"></i></span></div>
              <ul class="submenu">
                <li><a href="<?=$adres?>ders/ekle">Ders Ekle</a></li>
                <li><a href="<?=$adres?>ders">Dersler</a></li>
              </ul>
            </li>
            <li><div class="link"><i class="fa fa-pencil-square-o"></i><span>Sınavlar<i class="fa fa-chevron-right"></i></span></div>
              <ul class="submenu">
                <li><a href="<?=$adres?>sinav/ekle">Sınav Ekle</a></li>
                <li><a href="<?=$adres?>sinav/sonuc">Sınav Sonucu Ekle</a></li>
                <li><a href="<?=$adres?>sinav">Sınavlar</a></li>
              </ul>
            </li>
            <li><div class="link"><i class="fa fa-bullhorn"></i><span>Duyurular<i class="fa fa-chevron-right"></i></span></div>
                <ul class="submenu">
                  <li><a href="<?=$adres?>duyuru/ekle">Duyuru Ekle</a></li>
                  <li><a href="<?=$adres?>duyuru">Duyurular</a></li>
                </ul>
              </li>
              <li><div class="link"><i class="fa fa-hashtag"></i><span>Etkinlikler<i class="fa fa-chevron-right"></i></span></div>
                <ul class="submenu">
                  <li><a href="<?=$adres?>etkinlik/ekle">Etkinlik Ekle</a></li>
                  <li><a href="<?=$adres?>etkinlik">Etkinlikler</a></li>
                </ul>
              </li>
              <li><div class="link"><i class="fa fa-user"></i><span>Profil<i class="fa fa-chevron-right"></i></span></div>
                <ul class="submenu">
                  <li><a href="<?=$adres?>profil">Profil</a></li>
                  <li><a href="<?=$adres?>profil/sifre">Şifre Değiştir</a></li>
                </ul>
              </li>
              <li><div class="link"><i class="fa fa-users"></i><span>Kullanıcı<i class="fa fa-chevron-right"></i></span></div>
                  <ul class="submenu">
                      <li><a href="<?=$adres?>kullanici/ogrenci-ekle">Öğrenci Ekle</a></li>
                      <li><a href="<?=$adres?>kullanici/akdemisyen-ekle">Akademisyen Ekle</a></li>
                      <li><a href="<?=$adres?>kullanici">Kullanıcılar</a></li>
                  </ul>
              </li>
            </ul>
            <?php }else {?>
            <ul id="accordion">
            <li><a class="link" href="<?=$adres?>pano"><i class="fa fa-dashcube"></i><span>Pano</span></a></li>
            <li><a class="link" href="<?=$adres?>ders"><i class="fa fa-file-text"></i><span>Dersler</span></a></li>
            <li><a class="link" href="<?=$adres?>sinav"><i class="fa fa-pencil-square-o"></i><span>Sınavlar</span></a></li>
            <li><a class="link" href="<?=$adres?>duyuru"><i class="fa fa-bullhorn"></i><span>Duyurular</span></a></li>
            <li><a class="link" href="<?=$adres?>etkinlik"><i class="fa fa-hashtag"></i><span>Etkinlikler</span></a></li>
            <li><div class="link"><i class="fa fa-user"></i><span>Profil<i class="fa fa-chevron-right"></i></span></div>
                <ul class="submenu">
                  <li><a href="<?=$adres?>profil">Profil</a></li>
                  <li><a href="<?=$adres?>profil/sifre">Şifre Değiştir</a></li>
                </ul>
              </li>
            </ul>
            <?php }?>
        </nav>
        <div class="copyright">2024 &copy; MERP</div>
    </aside>
	<section>
	<header>
		<img src="<?=$adres?>images/logo.png" alt="Kpanel Logo" />
	  <a href="<?=$adres?>cikis?cikis=cik" title="Çıkış Yap"><i class="fa fa-sign-out"></i></a>
		<a href="<?=$adres?>../" target="_blank" title="Siteye Git"><i class="fa fa-globe"></i></a>
	</header>
	<div class="secbox <?=$url=='dosya.php' || $url=='kpanel.php'?'secboxdosya':''?>">
