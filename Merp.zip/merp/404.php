<!--Bismillahirrahmanirrahim-->
<!doctype html>
<html lang="tr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="images/favicon.png" rel="shortcut icon" />
<link href="css/panel.css" rel="stylesheet" type="text/css"/>

<title>MERP Öğrenci Yönetim Sistemi</title>
</head>
<body>
  <div class="dort404">
    <div></div>
    <span>Hata ! Böyle bir sayfa mevcut değil.</span>
    <a href="pano" class="buton">PANOYA DÖN</a>
  </div>
</body>
</html>
