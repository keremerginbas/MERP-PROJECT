<?php
$al  = $db->query("SELECT * FROM tb_kullanici ORDER BY kullanici_id DESC");
#Kayıt Yok Mesajı
$say = $al->rowCount();
if($say == "0") {
	echo '<div class="kayityok"><i class="fa fa-exclamation-circle"></i>Kayıtlı Kullanıcı Bulunmamaktadır.';
}else {
?>
<div class="genel-baslik">
	<h1>Tüm Kullanıcılar</h1>
</div>
<table id="yaziliste" class="display" style="width:100%">
  <thead>
	  <tr>
      <th>Kullanıcı Adı</th>
      <th>Kullanıcı Tipi</th>
      <th>E-Posta Adresi</th>
      <th>İşlemler</th>
	  </tr>
  </thead>
  <tbody>
	<?php $artir = 1;
	while($sql=$al->fetch(PDO::FETCH_ASSOC)) {?>
		<tr>
			<td><?=$sql['adi']?></td>
			<td><?=$sql['tip']=='1'?'Akademisyen':'Öğrenci'?></td>
			<td><?=$sql['eposta']?></td>
			<td width="110">
				<div class="datalist-araclar">
					<a href="#uyari<?=$artir?>" class="sil" title="Sil"><i class="fa fa-trash"></i></a>
				</div>
				<div id="uyari<?=$artir?>" class="modal-window"><!--Popup Mesaj Paneli-->
					<div>
						<a href="#" title="Kapat" class="modal-close">X</a>
						<h1>UYARI !</h1>
						<p>Bu kullanıcıyı silmek istediğinize emin misiniz ?</p>
						<a class="buton" href="<?=$adres?>kullanici?yazi=sil&id=<?=$sql['kullanici_id']?>">KULLANICIYI SİL</a>
					</div>
				</div>
			</td>
		</tr>
	<?php $artir++;}?>
  </tbody>
</table>
<?php
}//Kayıt bulamadım kapanış
#Kayıt Silme Kodları
if(@$_GET['yazi'] == 'sil') {
  $id = $_GET['id'];
  $db->query("DELETE FROM tb_kullanici WHERE kullanici_id = $id");
  header("Location:".$adres."kullanici");
}
?>
<script type="text/javascript">
$(document).ready(function() {
    $('#yaziliste').DataTable( {
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Turkish.json"
        },
				"order": [[ 3, "desc" ]]
    } );
} );
</script>
