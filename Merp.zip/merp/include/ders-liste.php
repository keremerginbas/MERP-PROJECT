<?php
$al  = $db->query("SELECT * FROM tb_ders ORDER BY ders_id DESC");
#Kayıt Yok Mesajı
$say = $al->rowCount();
if($say == "0") {
	echo '<div class="kayityok"><i class="fa fa-exclamation-circle"></i>Kayıtlı Ders Bulunmamaktadır.';
}else {
?>
<div class="genel-baslik">
	<h1><?php if($_SESSION['tip']=='2'){echo $_SESSION['adi'].' Derslerin';}else {echo 'Tüm Dersler';}?></h1>
</div>
<table id="yaziliste" class="display" style="width:100%">
  <thead>
	  <tr>
      <th>Ders Adı</th>
      <th>Ders Yeri</th>
      <th>İşlemler</th>
	  </tr>
  </thead>
  <tbody>
	<?php 
       if($_SESSION['tip']=='2'){
       $artir = 1;$dersi = $_SESSION['ders'];
	   while($sql=$al->fetch(PDO::FETCH_ASSOC)) {
       foreach (explode(",",$dersi) as $ders ){
       if($ders == $sql['ders_id']) {
    ?>
		<tr>
			<td><?=$sql['ders']?></td>
			<td><?=$sql['dersyeri']?></td>
			<td width="110">
				<div class="datalist-araclar">
					<a href="#uyari<?=$artir?>" class="sil" title="Sil"><i class="fa fa-trash"></i></a>
				</div>
				<div id="uyari<?=$artir?>" class="modal-window"><!--Popup Mesaj Paneli-->
					<div>
						<a href="#" title="Kapat" class="modal-close">X</a>
						<h1>UYARI !</h1>
						<p>Bu dersi silmek istediğinize emin misiniz ?</p>
						<a class="buton" href="<?=$adres?>ders?yazi=sil&id=<?=$sql['ders_id']?>">DERSİ SİL</a>
					</div>
				</div>
			</td>
		</tr>
	<?php $artir++;}}}}else {$artir = 1;while($sql=$al->fetch(PDO::FETCH_ASSOC)) {?>
			<tr>
			<td><?=$sql['ders']?></td>
			<td><?=$sql['dersyeri']?></td>
			<td width="110">
				<div class="datalist-araclar">
					<a href="#uyari<?=$artir?>" class="sil" title="Sil"><i class="fa fa-trash"></i></a>
				</div>
				<div id="uyari<?=$artir?>" class="modal-window"><!--Popup Mesaj Paneli-->
					<div>
						<a href="#" title="Kapat" class="modal-close">X</a>
						<h1>UYARI !</h1>
						<p>Bu dersi silmek istediğinize emin misiniz ?</p>
						<a class="buton" href="<?=$adres?>ders?yazi=sil&id=<?=$sql['ders_id']?>">DERSİ SİL</a>
					</div>
				</div>
			</td>
		</tr>
		<?php }}?>
  </tbody>
</table>
<?php
}//Kayıt bulamadım kapanış
#Kayıt Silme Kodları
if(@$_GET['yazi'] == 'sil') {
  $id = $_GET['id'];
  $db->query("DELETE FROM tb_ders WHERE ders_id = $id");
  header("Location:".$adres."ders");
}
?>
<script type="text/javascript">
$(document).ready(function() {
    $('#yaziliste').DataTable( {
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Turkish.json"
        },
				"order": [[ 2, "desc" ]]
    } );
} );
</script>
