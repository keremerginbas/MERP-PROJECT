<?php include'araclar/class.upload.php';
if($_SESSION['tip']=='2'){header("Location:".$adres."ders");}
if(@$_POST['kaydet']) {
	$eposta = suz(strip_tags($_POST['eposta']));
	$adi    = suz(strip_tags($_POST['adi']));
	$kadi   = $seo->bosluksil($_POST['kadi']);
	$sifre1 = suz(strip_tags($_POST['ysifre1']));
	$sifre2 = suz(strip_tags($_POST['ysifre2']));

	$foto   = new Upload($_FILES['foto'], 'tr_TR');

	$epostaal = $db->query("SELECT * FROM tb_kullanici WHERE eposta='$eposta'");
	if($epostaal->rowCount() == 0) {#1
		$kullanicial = $db->query("SELECT * FROM tb_kullanici WHERE kullanici='$kadi'");
		if($kullanicial->rowCount() == 0) {#2
			if($sifre1 == $sifre2) {#3
				$tarih = date('Y.m.d H:i:s');
				$sifre = sifre($sifre1);

				$db->exec("INSERT INTO tb_kullanici(kullanici,sifre,eposta,adi,durum,tarih,kpanel,tip) VALUES('$kadi','$sifre','$eposta','$adi','0','$tarih','1','1')");

				$mesaj = 'Akademisyen eklendi.';
				$durum = 'dogru';
				$eposta = '';
				$adi    = '';
				$kadi   = '';
                $ders   = '';
				$sifre1 = '';
				$sifre2 = '';
			}else {	//#3 Şifreler uyuşmuyor
				$mesaj    = 'Şifreleriniz aynı değil.';
				$durum    = 'hata';
				$renk[3]  = $hatarenk;
				$renk[4]  = $hatarenk;
				$focus[1] = 'autofocus';
				$ysifre1  = '';
				$ysifre2  = '';
			}
		}else {	//#2 Kayıtlı kullanıcı adı
			$mesaj    = 'Bu kullanıcı adı ile kayıtlı kullanıcı mevcut.';
			$durum    = 'hata';
			$renk[1]  = $hatarenk;
			$focus[0] = 'autofocus';
			$kadi     = '';
		}
	}else { //#1 Kayıtlı kullanıcı epostası
		$mesaj   = 'Bu eposta adresi ile kayıtlı kullanıcı mevcut.';
		$durum   = 'hata';
		$renk[0] = $hatarenk;
		$eposta  = '';
	}

	if($foto->uploaded) {#4
		$yenisim = substr(sifre(rand()),0,10);
		$foto->mime_check = true; //Güvenlik
		$foto->no_script = true; //Güvenlik
		$foto->image_resize = true;
		$foto->image_x = 150;
		$foto->image_ratio_y = true;
		$foto->file_new_name_body = $foto->file_src_name_body."-".$yenisim;
		$foto->allowed = array('image/jpeg','image/jpg');
		$foto->Process('images/profil');
		if($foto->processed) {#5
			$adresu = 'images/profil/'.$foto->file_dst_name;

			$db->exec("UPDATE tb_kullanici SET foto='$adresu' WHERE kullanici_id = $kullaniciid");

		}else {  //#5 Resim kritelerinde hata.
			$mesaj   = $foto->error;
			$durum   = 'hata';
			$renk[2] = $hatarenk;
		}
	}
}
$dersal = $db->query("SELECT * FROM tb_ders");
?>
<div class="genel-baslik">
	<h1>Akademisyen Ekle</h1>
  <a class="ustdizin" href="<?=$adres?>kullanici"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="ekle profil">
	<form action="<?=$_SERVER['REQUEST_URI']?>#m" method="post"  enctype="multipart/form-data">
		<div class="ekleliste bol">
          <div class="bol2">
			<label>Adı Soyadı</label>
			<input type="text" name="adi" maxlength="249"  placeholder="Adı Soyadı" value="<?=@$adi?>" required>
			<i></i>
		  </div>
		  <div class="bol2">
			<label>E-Posta Adresi</label>
			<input  type="text" name="eposta" placeholder="E-Posta adresi" value="<?=@$eposta?>" required <?=empty($focus)?'autofocus':'';?> <?=@$renk[0]?>>
			<i></i>
          </div>
		</div>
		<div class="ekleliste bol">
			<div class="bol2">
				<label>Kullanıcı Adı</label>
				<input type="text" name="kadi" maxlength="99"  placeholder="Kullanıcı adı" value="<?=@$kadi?>" required <?=@$focus[0]?> <?=@$renk[1]?>>
				<i></i>
			</div>
			<div class="bol2">
				<label>Profil Fotoğrafı <span class="bilgi" title="Fotoğraf 150x150px jpeg formatında olmalıdır.">?</span></label>
				<input type="file" name="foto" <?=@$renk[2]?>  accept="image/jpg">
			</div>
		</div>
		<div class="ekleliste bol">
			<div class="bol2">
				<label>Şifre<span class="bilgi" title="Şifre en az 6 karakter olmalıdır.">?</span></label>
				<input type="password" name="ysifre1" minlength="6" maxlength="25" <?=@$focus[1]?> <?=@$renk[3]?> required>
				<i></i>
			</div>
			<div class="bol2">
				<label>Şifre Terar<span class="bilgi" title="Şifre en az 6 karakter olmalıdır.">?</span></label>
				<input type="password" name="ysifre2" minlength="6" maxlength="25" <?=@$renk[4]?> required>
				<i></i>
			</div>
		</div>
    <div id="m" class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="OLUŞTUR">
	</form>
</div>
