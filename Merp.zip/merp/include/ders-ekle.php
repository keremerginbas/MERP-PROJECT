<?php
if($_SESSION['tip']=='2'){header("Location:".$adres."ders");}
if(@$_POST['kaydet']) {
  $ders = strip_tags($_POST['ders']);
  $yeri = strip_tags($_POST['yeri']);
  $db->exec("INSERT INTO tb_ders(ders,dersyeri) VALUES('$ders','$yeri')");
  
  $durum  = 'dogru';
  $mesaj  = 'Tebrikler, Ders sisteme eklendi.';
}
?>
<div class="genel-baslik">
	<h1>Ders Ekle</h1>
  <a class="ustdizin" href="<?=$adres?>ders"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="ekle">
	<form action="<?=$_SERVER['REQUEST_URI']?>#m" method="post" enctype="multipart/form-data">
		<div class="ekleliste">
			<label>Ders Adı<span class="bilgi" title="Ders adı için girilen cümle 50 karakteri geçmemelidir.">?</span></label>
			<input autofocus type="text" name="ders" placeholder="Matematik" maxlength="50" value="<?=@$ders?>" required>
			<i></i>
		</div>
		<div class="ekleliste">
			<label>Ders Yeri<span class="bilgi" title="Ders adı için girilen cümle 50 karakteri geçmemelidir.">?</span></label>
			<input autofocus type="text" name="yeri" placeholder="Kampüs" maxlength="50" value="<?=@$yeri?>" required>
			<i></i>
		</div>
    <div id="m" class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="DERSİ EKLE">
	</form>
</div>
