<?php
if($_SESSION['tip']=='2'){header("Location:".$adres."ders");}
if(@$_POST['kaydet']) {
  $etkinlik = strip_tags($_POST['etkinlik']);
  $metin    = strip_tags($_POST['metin']);
  $db->exec("INSERT INTO tb_etkinlik(etkinlik,metin) VALUES('$etkinlik','$metin')");
  
  $etkinlik = '';
  $metin    = '';
  $durum    = 'dogru';
  $mesaj    = 'Tebrikler, Etkinlik sisteme eklendi.';
}
?>
<div class="genel-baslik">
  <h1>Etkinlik Ekle</h1>
  <a class="ustdizin" href="<?=$adres?>etkinlik"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="ekle">
	<form action="<?=$_SERVER['REQUEST_URI']?>#m" method="post" enctype="multipart/form-data">
		<div class="ekleliste">
			<label>Etkinlik Adı<span class="bilgi" title="Etkinlik başlığı için girilen cümle 100 karakteri geçmemelidir.">?</span></label>
			<input autofocus type="text" name="etkinlik" placeholder="Başlık" maxlength="100" value="<?=@$etkinlik?>" required>
			<i></i>
		</div>
		<div class="ekleliste">
			<label>Duyuru Detayı</label>
			<textarea name="metin" placeholder="Etkinlik metni" required><?=@$metin?></textarea>
			<i></i>
		</div>
    <div id="m" class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="ETKİNLİK EKLE">
	</form>
</div>
