<?php
$al  = $db->query("SELECT * FROM tb_duyuru ORDER BY duyuru_id DESC");
#Kayıt Yok Mesajı
$say = $al->rowCount();
if($say == "0") {
	echo '<div class="kayityok"><i class="fa fa-exclamation-circle"></i>Kayıtlı Duyuru Bulunmamaktadır.';
}else {
?>
<div class="genel-baslik">
	<h1>Tüm Duyurular</h1>
	
</div>
<table id="yaziliste" class="display" style="width:100%">
  <thead>
	  <tr>
      <th>Duyuru</th>
      <th>Duyuru Metin</th>
      <th>İşlemler</th>
	  </tr>
  </thead>
  <tbody>
	<?php $artir = 1;
	while($sql=$al->fetch(PDO::FETCH_ASSOC)) {?>
		<tr>
			<td><?=$sql['duyuru']?></td>
			<td><?=mb_substr($sql['metin'],0,50,'UTF-8')?></td>
			<td width="110">
				<div class="datalist-araclar">
					<a href="#uyari<?=$artir?>" class="sil" title="Sil"><i class="fa fa-trash"></i></a>
					<a href="#duyuru<?=$artir?>" class="sil" title="Detay"><i class="fa fa-envelope-open-o"></i></a>
				</div>
				<div id="duyuru<?=$artir?>" class="modal-window"><!--Popup Mesaj Paneli-->
					<div>
						<a href="#" title="Kapat" class="modal-close">X</a>
						<h1>Duyuru Detayı</h1>
						<p><?=$sql['duyuru']?></p>
						<p><?=$sql['metin']?></p>
					</div>
				</div>
				<div id="uyari<?=$artir?>" class="modal-window"><!--Popup Mesaj Paneli-->
					<div>
						<a href="#" title="Kapat" class="modal-close">X</a>
						<h1>UYARI !</h1>
						<p>Bu duyuruyu silmek istediğinize emin misiniz ?</p>
						<a class="buton" href="<?=$adres?>duyuru?yazi=sil&id=<?=$sql['duyuru_id']?>">DUYURUYU SİL</a>
					</div>
				</div>
			</td>
		</tr>
	<?php $artir++;}?>
  </tbody>
</table>
<?php
}//Kayıt bulamadım kapanış
#Kayıt Silme Kodları
if(@$_GET['yazi'] == 'sil') {
  $id = $_GET['id'];
  $db->query("DELETE FROM tb_duyuru WHERE duyuru_id = $id");
  header("Location:".$adres."duyuru");
}
?>
<script type="text/javascript">
$(document).ready(function() {
    $('#yaziliste').DataTable( {
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Turkish.json"
        },
				"order": [[ 2, "desc" ]]
    } );
} );
</script>
