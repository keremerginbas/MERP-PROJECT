<?php
if($_SESSION['tip']=='2'){header("Location:".$adres."ders");}


if(@$_GET['kaydet']) {
  $sinav = strip_tags($_GET['dersi']);
  $ogren = $_GET['ogrenci'];
  
  foreach($ogren as $id => $not) {
    $db->exec("INSERT INTO tb_sonuc(sinav_id,sonuc,kullanici_id) VALUES('$sinav','$not','$id')");
  }
  
  $ogrenci = '';
  $durum  = 'dogru';
  $mesaj  = 'Tebrikler, Sınav sonucu sisteme eklendi.';
}
 
?>
<div class="genel-baslik">
	<h1>Sınav Sonucu Ekle</h1>
  <a class="ustdizin" href="<?=$adres?>sinav"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="ekle">
<?php if(@$_GET['ders'] || @$_GET['dersi']){?>
	<form action="<?=$_SERVER['REQUEST_URI']?>" method="get">
      <div class="ekleliste">
		<?php 
        if(@$_GET['ders']) {$dersi  = @$_GET['ders'];}else {$dersi  = @$_GET['dersi'];}
        $dersal = $db->query("SELECT * FROM tb_sinav WHERE sinav_id=".$dersi."")->fetch(PDO::FETCH_ASSOC);
        $ogral  = $db->query("SELECT kullanici_id,adi FROM tb_kullanici WHERE tip=2 && ders LIKE '%".$dersi."%'");
        ?>
        <div>
            <label><?=$dersal['sinav']?> Sonuçları Ekle</label>
            <select name="dersi">
              <option value="<?=$dersal['sinav_id']?>"><?=$dersal['sinav']?></option> 
            </select>
        </div>
      </div>
      <div class="ekleliste bol">
       <?php while($ogr = $ogral->fetch(PDO::FETCH_ASSOC)){?>
        <div class="bol2">
           <label><?=$ogr['adi']?></label>
           <input name="ogrenci[<?=$ogr['kullanici_id']?>]" type="number" placeholder="50" min="0" max="100">
        </div>
        <?php }?>
      </div>
    <div id="m" class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="SONUÇLARI EKLE">
	</form>
<?php }else {?>
      <form action="<?=$_SERVER['REQUEST_URI']?>" method="get">
      <div class="ekleliste">
		<?php 
        $dersal = $db->query("SELECT * FROM tb_sinav ORDER BY sinav_id DESC");
        $sonuc  = $db->query("SELECT sinav_id FROM tb_sonuc");
        ?>
        <div>
            <label>Sonuç Eklenecek Sınav</label>
            <select name="ders">
              <option>Sınav Seçin</option> 
              <?php while($ders=$dersal->fetch(PDO::FETCH_ASSOC)){?>
              <option value="<?=$ders['sinav_id']?>" <?php foreach($sonuc as $sonucid){if($ders['sinav_id']==$sonucid['sinav_id']){echo'disabled';}} ?>><?=$ders['sinav']?></option>
              <?php }?>
            </select>
        </div>
      </div>
    <input type="submit" value="DEVAM ET">
	</form>
<?php }?>
</div>
