<?php
$id = (int) $_SESSION['user'];

$kullanicial = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id=$id");
$sql 		 = $kullanicial->fetch(PDO::FETCH_ASSOC);

if(@$_POST['kaydet']) {
	$esifre  = suz(strip_tags($_POST['esifre']));
	$ysifre1 = suz(strip_tags($_POST['ysifre1']));
	$ysifre2 = suz(strip_tags($_POST['ysifre2']));

	if($sql['sifre'] == sifre($esifre)) {
		if(!empty($ysifre1) || !empty($ysifre2)) {
			if($ysifre1 == $ysifre2) {

				$sifre   = sifre($ysifre1);
	      $duzenle = $db->exec("UPDATE tb_kullanici SET sifre='$sifre' WHERE kullanici_id=$id");

				$mesaj   = 'Tebrikler şifreniz güncellendi.';
				$durum   = 'dogru';

			}else {
				$mesaj   = 'Yeni şifreler aynı değil.';
				$durum   = 'hata';
				$renk[1] = $hatarenk;
				$renk[2] = $hatarenk;
			}
		}else {
			$mesaj   = 'Yeni şifre alanlarını eksiksiz doldurun.';
			$durum   = 'hata';
			$renk[1] = $hatarenk;
			$renk[2] = $hatarenk;
		}
	}else {
		$mesaj   = 'Eski şifrenizi hatalı girdiniz.';
		$durum   = 'hata';
		$renk[0] = $hatarenk;
	}
}

$sql = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id=$id")->fetch(PDO::FETCH_ASSOC);
?>
<div class="genel-baslik">
	<h1>Şifre Değiştirme</h1>
    <a class="ustdizin" href="<?=$adres?>profil"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="profil-ozet">
	<i class="fa fa-user"></i><?=!empty($sql['foto'])?'<img src="'.$adres.$sql['foto'].'" alt="profil" />':'';?>
    <div>
    	<span><?=$sql['adi']?></span>
        <b><?=$sql['eposta']?></b>
        <i><?=$sql['kullanici']?></i>
    </div>
</div>
<div class="ekle profil">
	<form action="<?=$_SERVER['REQUEST_URI']?>" method="post">
		<div class="ekleliste">
			<label>Eski Şifre</label>
			<input type="password" name="esifre" maxlength="25" required <?=@$renk[0]?>>
			<i></i>
		</div>
		<div class="ekleliste">
			<label>Yeni Şifre
				<span class="bilgi" title="Yeni şifreniz en az 6 karakter olmalıdır.">?</span>
			</label>
			<input type="password" name="ysifre1" minlength="6" maxlength="25" required <?=@$renk[1]?>>
			<i></i>
		</div>
		<div class="ekleliste">
			<label>Yeni Şifre Terar
				<span class="bilgi" title="Yeni şifreniz en az 6 karakter olmalıdır.">?</span>
			</label>
			<input type="password" name="ysifre2" minlength="6" maxlength="25" required <?=@$renk[2]?>>
			<i></i>
		</div>
    <div class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="ŞiFREYİ DEĞİŞTİR">
	</form>
</div>
