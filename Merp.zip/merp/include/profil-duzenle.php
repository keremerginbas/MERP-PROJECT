<?php include'araclar/class.upload.php';

$id = (int) $_SESSION['user'];

$kullanicial = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id=$id");
$sql 		 		 = $kullanicial->fetch(PDO::FETCH_ASSOC);

if(@$_POST['kaydet']) {
	$eposta = suz(strip_tags($_POST['eposta']));
	$adi    = suz(strip_tags($_POST['adi']));
	$kadi   = $seo->bosluksil($_POST['kadi']);
	$gorunum= (int) $_POST['gorunum'];
	$foto   = new Upload($_FILES['resim'], 'tr_TR');

	    $kullanicisor = $db->query("SELECT * FROM tb_kullanici WHERE kullanici='$kadi' && kullanici_id!='$id'");
			if($kullanicisor->rowCount() !== 1) {
				$epostasor = $db->query("SELECT * FROM tb_kullanici WHERE eposta='$eposta' && kullanici_id!='$id'");
			  if($epostasor->rowCount() !== 1) {
				  $db->exec("UPDATE tb_kullanici SET adi='$adi',kullanici='$kadi',eposta='$eposta',kpanel='$gorunum' WHERE kullanici_id=$id");

				  $mesaj   = 'Tebrikler profiliniz güncellendi.';
				  $durum   = 'dogru';
					header("Refresh: 1; url=".$_SESSION['sonlink']."");
			  }else {
				  $mesaj    = 'Bu eposta ile kayıtlı kullanıcı mevcut.';
				  $durum    = 'hata';
				  $renk[2]  = $hatarenk;
			  }
	    }else {
				$mesaj    = 'Bu kullanıcı adı ile kayıtlı kullanıcı mevcut.';
				$durum    = 'hata';
				$renk[1]  = $hatarenk;

			}
			if($foto->uploaded) {
				$yenisim = substr(sifre(rand()),0,10);
				$foto->mime_check = true; //Güvenlik
				$foto->no_script = true; //Güvenlik
				$foto->image_resize = true;
				$foto->image_x = 150;
				$foto->image_ratio_y = true;
				$foto->file_new_name_body = $foto->file_src_name_body."-".$yenisim;
				$foto->allowed = array('image/jpeg','image/jpg');
				$foto->Process('images/profil');
					if($foto->processed) {
							$adres = 'images/profil/'.$foto->file_dst_name;
							$fotoal = $db->query("SELECT foto FROM tb_kullanici WHERE kullanici_id = $id")->fetch(PDO::FETCH_ASSOC);
							unlink("".$fotoal['foto']."");
							$db->exec("UPDATE tb_kullanici SET foto='$adres' WHERE kullanici_id=$id");

							$mesaj   = 'Tebrikler profiliniz güncellendi.';
							$durum   = 'dogru';
							header("Refresh:2;url=profil");

					}else {
							$durum = 'hata';
							$mesaj = $foto->error;
					}
				}
}

$kullanicial = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id=$id");
$sql 		 = $kullanicial->fetch(PDO::FETCH_ASSOC);

//Kullanıcı silme kontrolü
$kal = $db->query("SELECT * FROM tb_kullanici WHERE durum = 0");
if($kal->rowCount() >= 2) {
		$sil = '<p>Bu kullanıcıyı silmek istediğinize eminmisiniz.</p><a class="buton" href="'.$adres.'kullanici?is=sil&id='.$sql['kullanici_id'].'">KULLNICIYI SİL</a>';
}else {
	  $sil = '<p>Bu kullanıcıyı silebilmeniz için en az 2 kullanıcıya ihtiyaç vardır.</p>';
}

?>
<div id="uyari" class="modal-window"><!--Popup Mesaj Paneli-->
	<div>
		<a href="#" title="Kapat" class="modal-close">X</a>
		<h1>UYARI !</h1>
		<?=$sil?>
	</div>
</div>
<div class="genel-baslik">
	<h1>Profil</h1>
    <a class="ustdizin" href="<?=$adres?>profil/sifre"><i class="fa fa-lock"></i> Şifre Değiştir</a>
</div>
<div class="profil-ozet">
	<i class="fa fa-user"></i><?=!empty($sql['foto'])?'<img src="'.$adres.$sql['foto'].'" alt="profil" />':'';?>
    <div>
    	<span><?=$sql['adi']?></span>
      <b><?=$sql['eposta']?></b>
      <i><?=$sql['kullanici']?></i>
    </div>
    <a title="Profili Kaldır" href="#uyari"><i class="fa fa-trash"></i></a>
</div>
<div class="ekle profil">
	<form action="<?=$_SERVER['REQUEST_URI']?>" method="post"  enctype="multipart/form-data">
		<div class="ekleliste">
			<label>E-Posta Adresi</label>
			<input type="email" name="eposta" value="<?=$sql['eposta']?>" required <?=@renk[2]?>>
		</div>
		<div class="ekleliste">
			<label>Adı Soyadı</label>
			<input type="text" name="adi" maxlength="249" value="<?=$sql['adi']?>" autofocus required>
			<i></i>
		</div>
		<div class="ekleliste bol">
			<div class="bol3">
				<label>Kullanıcı Adı</label>
				<input type="text" name="kadi" maxlength="99" value="<?=$sql['kullanici']?>"  required <?=@$renk[1]?>>
				<i></i>
			</div>
			<div class="bol3">
				<label>Profil Fotoğrafı
					<span class="bilgi" title="Sadece 150x150px JPG fotoğraf yükleyebilirsiniz">?</span>
				</label>
				<input type="file" name="resim" accept=".jpg">
			</div>
			<div class="bol3">
				<label>Kpanel Görünümü</label>
				<select name="gorunum">
					<option value="1" <?=$sql['kpanel']=='1'?'selected':''?>>Pencere</option>
					<option value="2" <?=$sql['kpanel']=='2'?'selected':''?>>Tam Ekran</option>
				</select>
			</div>
		</div>
    <div class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="PROFİLİ GÜNCELLE">
	</form>
</div>
