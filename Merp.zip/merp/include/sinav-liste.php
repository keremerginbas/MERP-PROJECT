<?php
$al  = $db->query("SELECT * FROM tb_etkinlik ORDER BY etkinlik_id DESC");
#Kayıt Yok Mesajı
$say = $al->rowCount();
if($say == "0") {
	echo '<div class="kayityok"><i class="fa fa-exclamation-circle"></i>Kayıtlı Sınav Bulunmamaktadır.';
}else {
$al = $db->query("SELECT * FROM tb_sinav ORDER BY sinav_id DESC");
?>
<div class="genel-baslik">
	<h1><?php if($_SESSION['tip']=='2'){echo $_SESSION['adi'].' Sınavların';}else {echo 'Tüm Sınavlar';}?></h1>
</div>
<div class="kullanicilar">
	<?php 
    if($_SESSION['tip']=='2'){
    $dersi = $_SESSION['ders'];
    while($sql = $al->fetch(PDO::FETCH_ASSOC)) {
      foreach (explode(",",$dersi) as $ders ){
        if($ders==$sql['ders_id']) {
          $di = '1';
    ?>
	<div class="kullanici" style="height:250px;">
    	<div>
    		<i class="fa fa-pencil-square-o"></i>
    		<span><?=$sql['sinav']?></span>
            <b style="margin-bottom:15px;"><?=$zaman->tumzaman($sql['tarih'])?></b>
            <?php $sonuc = $db->query("SELECT * FROM tb_sonuc WHERE sinav_id=".$sql['ders_id']." && kullanici_id=".$_SESSION['user']." LIMIT 0,1")->fetch(PDO::FETCH_ASSOC)?>
            <?php if(!empty($sonuc['sonuc'])){?><span>Sınav Sonucu: <?=@$sonuc['sonuc']?></span><?php }?>
		</div>
    </div>
    <?php }}}if(@$di!=='1'){echo '<div class="kayityok"><i class="fa fa-exclamation-circle"></i>Kayıtlı Sınavın Bulunmamaktadır.';}}else {while($sql = $al->fetch(PDO::FETCH_ASSOC)) {?>
    <div class="kullanici">
    	<div>
    		<i class="fa fa-pencil-square-o"></i>
    		<span><?=$sql['sinav']?></span>
        <b><?=$zaman->tumzaman($sql['tarih'])?></b>
		</div>
    </div>
    <?php }}?>
</div>
<?php
}//Kayıt bulamadım kapanış
?>
