<?php
if($_SESSION['tip']=='2'){header("Location:".$adres."ders");}
if(@$_POST['kaydet']) {
  $sinav= strip_tags($_POST['sinav']);
  $yeri = strip_tags($_POST['yeri']);
  $ders = $_POST['ders'];
  $tarih= $_POST['tarih'];
  $db->exec("INSERT INTO tb_sinav(sinav,tarih,ders_id,sinavyeri) VALUES('$sinav','$tarih','$ders','$yeri')");
  
  $sinav = '';
  $yeri = '';
  $ders = '';
  $tarih = '';
  $durum  = 'dogru';
  $mesaj  = 'Tebrikler, Sınav sisteme eklendi.';
}
?>
<div class="genel-baslik">
	<h1>Sınav Ekle</h1>
  <a class="ustdizin" href="<?=$adres?>sinav"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="ekle">
	<form action="<?=$_SERVER['REQUEST_URI']?>#m" method="post" enctype="multipart/form-data">
      <div class="ekleliste bol">
		<div class="bol2">
		  <label>Sınav Adı<span class="bilgi" title="Sınav adı için girilen cümle 100 karakteri geçmemelidir.">?</span></label>
		  <input autofocus type="text" name="sinav" placeholder="Matematik Sınavı" maxlength="100" value="<?=@$sinav?>" required>
		  <i></i>
		</div>
		<div  class="bol2">
            <label>Sınav Tarihi<span class="bilgi" title="Sınavın yapılacağı tarihi seçin">?</span></label>
            <input type="datetime-local" name="tarih" value="<?=@$tarih?>" required>
            <i></i>
        </div>
      </div>
      <div class="ekleliste bol">
		<div class="bol2">
			<label>Sınav Yeri<span class="bilgi" title="Ders adı için girilen cümle 50 karakteri geçmemelidir.">?</span></label>
			<input autofocus type="text" name="yeri" placeholder="Kampüs" maxlength="50" value="<?=@$yeri?>" required>
			<i></i>
		</div>
       <?php $dersal = $db->query("SELECT * FROM tb_ders ORDER BY ders_id DESC");?>
        <div class="bol2">
            <label>Sınav Dersi</label>
            <select name="ders">
              <?php while($ders=$dersal->fetch(PDO::FETCH_ASSOC)){?>
              <option value="<?=$ders['ders_id']?>"><?=$ders['ders']?></option>
              <?php }?>
            </select>
        </div>
      </div>
    <div id="m" class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="SINAV EKLE">
	</form>
</div>
