<?php
if($_SESSION['tip']=='2'){header("Location:".$adres."ders");}
if(@$_POST['kaydet']) {
  $duyuru = strip_tags($_POST['duyuru']);
  $metin  = strip_tags($_POST['metin']);
  $db->exec("INSERT INTO tb_duyuru(duyuru,metin) VALUES('$duyuru','$metin')");
  
  $duyuru = '';
  $metin  = '';
  $durum  = 'dogru';
  $mesaj  = 'Tebrikler, Duyuru sisteme eklendi.';
}
?>
<div class="genel-baslik">
	<h1>Duyuru Ekle</h1>
  <a class="ustdizin" href="<?=$adres?>duyuru"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="ekle">
	<form action="<?=$_SERVER['REQUEST_URI']?>#m" method="post" enctype="multipart/form-data">
		<div class="ekleliste">
			<label>Duyuru Adı<span class="bilgi" title="Duyuru adı için girilen cümle 100 karakteri geçmemelidir.">?</span></label>
			<input autofocus type="text" name="duyuru" placeholder="Başlık" maxlength="100" value="<?=@$duyuru?>" required>
			<i></i>
		</div>
		<div class="ekleliste">
			<label>Duyuru Detayı</label>
			<textarea name="metin" placeholder="Duyuru metni" required><?=@$metin?></textarea>
			<i></i>
		</div>
    <div id="m" class="bilgimesaj <?=@$durum?>"><?=@$mesaj?></div>
    <input type="submit" name="kaydet" value="DUYURU EKLE">
	</form>
</div>
