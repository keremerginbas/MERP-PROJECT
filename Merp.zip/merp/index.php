<?php
ob_start();
session_start();

include('araclar/baglanti.php');
include('araclar/canta.php');

if(isset($_SESSION['adi']) && isset($_SESSION['foto'])) { header("Location:".$yolpanel."giris");}

if(@$_POST['giris']){
	$login  = htmlspecialchars(strip_tags($_POST['login']));
	$sifre  = sifre(strip_tags($_POST['sifre']));
	$oturum = @$_POST['oturum'];
	$sorgu  = $db->query("SELECT * FROM tb_kullanici WHERE (kullanici='$login' || eposta='$login') && sifre='$sifre'");
	$sonuc  = $sorgu->rowCount();

    if ($sonuc == 1) {
		$al = $sorgu->fetch(PDO::FETCH_ASSOC);

		$_SESSION['user']   = $al['kullanici_id'];
        $_SESSION['tip']   = $al['tip'];
        $_SESSION['ders']   = $al['ders'];
		$_SESSION['sifre']  = 'giris';
		$_SESSION['isim']   = $login;
		$_SESSION['adi']	  = $al['adi'];
		$_SESSION['foto']	  = $al['foto'];
		$_SESSION['cikis']  = time();
		if(!empty($oturum)) { $_SESSION['cikis2'] = 86400;}
		//echo "<script type=\"text/javascript\">alert('Giriş Başarılı');</script>";
		header("Location:".$yolpanel."pano");
	}
	else
	 {
		$mesaj  = '<div class="bilgi">Hatalı Giriş ! Tekrar Deneyiniz.</div>';
		$renk 	= 'style="border-color:#C00;"';
		session_destroy();
	 }
}
?>
<!--Bismillahirrahmanirrahim-->
<!doctype html>
<html lang="tr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/giris.css" />
<link rel="stylesheet" href="css/font-awesome.min.css" />
<link href="images/favicon.png" rel="shortcut icon" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>MERP Öğrenci Yönetim Sistemi</title>
</head>
<body>
<div class="giris">
  <div class="baslik"></div>
  <form class="form" method="post">
    <span>
      <input type="text" placeholder="Kullanıcı Adı veya E-Posta" name="login" required <?=@$renk?> autofocus>
      <i class="fa fa-user"></i>
    </span>
    <span>
      <input type="password" placeholder="Parola" name="sifre" required <?=@$renk?>>
      <i class="fa fa-lock"></i>
    </span>
    <div class="temiz"></div>
    <input type="checkbox" name="oturum" id="oturum">
    <label for="oturum">Oturumu açık tut</label>
    <a class="sag" href="sifre">Şifremi Unuttum</a>
    <div class="temiz"></div>
    <?=@$mesaj?>
    <input type="submit" name="giris" value="GİRİŞ YAP" >
  </form>
</div>
</body>
</html>
<?php ob_end_flush();?>
