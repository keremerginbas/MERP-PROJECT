<?php
require_once'panelust.php';

@$sayfa = $_GET['sy'];

switch ($sayfa) {
	case 'ekle':
		include'include/ders-ekle.php';
		break;
	default:
		include'include/ders-liste.php';
		break;
}

require_once'panelalt.php';
?>
