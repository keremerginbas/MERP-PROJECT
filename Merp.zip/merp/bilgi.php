<?php 
require_once'panelust.php';

@$sayfa = $_GET['sy'];

switch ($sayfa) {
	case 'hakkimizda':
		include'include/bilgi-hakkimizda.php';
		break;
	case 'medya':
		include'include/bilgi-medya.php';
		break;	
	default:
		include'include/bilgi-iletisim.php';
		break;
}

require_once'panelalt.php';
?>