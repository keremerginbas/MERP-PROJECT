<?php
require_once'panelust.php';

@$sayfa = $_GET['sy'];

switch ($sayfa) {
	case 'ekle':
		include'include/sinav-ekle.php';
		break;
    case 'sonuc':
		include'include/sinav-sonuc.php';
		break;
	default:
		include'include/sinav-liste.php';
		break;
}

require_once'panelalt.php';
?>
