    </div>
  </section>
</div>
</body>
<script>
  $('#editor').summernote({
    placeholder: 'İçerik metnini girin',
    tabsize: 2,
    height: 500,
    lang: 'tr-TR',
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'underline', 'clear']],
      ['fontname', ['fontname']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['table', ['table']],
      ['insert', ['link', 'image','elfinder']],
      ['view', ['fullscreen', 'codeview']],
    ],
  });
  function elfinderDialog(context){ // <------------------ +context
      var fm = $('<div/>').dialogelfinder({
          url : '<?=$adres?>araclar/elFinder/php/connector.minimal.php',
          lang : 'tr',
          width : 1100,
          height: 700,
          destroyOnClose : true,
          getFileCallback : function(file, fm) {
              console.log(file);
              // $('.editor').summernote('editor.insertImage', fm.convAbsUrl(file.url)); ...before
              context.invoke('editor.insertImage', fm.convAbsUrl(file.url)); // <------------ after
          },
          commandsOptions : {
              getfile : {
                  oncomplete : 'close',
                  folders : false
              }
          }
      }).dialogelfinder('instance');
  }
</script>
<script src="<?=$adres?>js/jquery.mousewheel-3.0.6.pack.js" type="text/javascript"></script>
<script src="<?=$adres?>js/menu.js"></script>
<script src="<?=$adres?>js/jquery.tipsy.js"></script>
<script src="<?=$adres?>js/dropdown.js"></script>
</html>
<?php
ob_end_flush();$db=null;?>
