<?php
require_once'panelust.php';
@$sayfa = $_GET['sy'];
switch ($sayfa) {
	case 'ekle':
		include'include/duyuru-ekle.php';
		break;
	default:
		include'include/duyuru-liste.php';
		break;
}
require_once'panelalt.php';
?>
