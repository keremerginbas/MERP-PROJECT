<?php
require_once'panelust.php';
@$sayfa = $_GET['sy'];
switch ($sayfa) {
	case 'ekle':
		include'include/etkinlik-ekle.php';
		break;
	default:
		include'include/etkinlik-liste.php';
		break;
}
require_once'panelalt.php';
?>
