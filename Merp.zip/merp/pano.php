<?php
include'panelust.php';
$tarihal = date("Y-m-d");
$tarih = explode("-",$tarihal);

$istatistik1 = $db->query("SELECT COUNT(sinav_id) as toplam FROM tb_sinav")->fetch(PDO::FETCH_ASSOC);
$istatistik2 = $db->query("SELECT COUNT(ders_id) as toplam FROM tb_ders")->fetch(PDO::FETCH_ASSOC);
$istatistik3 = $db->query("SELECT COUNT(duyuru_id) as toplam FROM tb_duyuru")->fetch(PDO::FETCH_ASSOC);
$istatistik4 = $db->query("SELECT COUNT(etkinlik_id) as toplam FROM tb_etkinlik")->fetch(PDO::FETCH_ASSOC);
?>
    	 <div class="bilgi-kutubox">
            <div class="bilgi-kutu renk1">
                <h3>Toplam Sınav</h3>
                <i class="fa fa-pencil-square-o fa-2x"></i>
                <b><?=@sayiformati($istatistik1['toplam'])?></b>
            </div>
            <div class="bilgi-kutu renk2">
                <h3>Toplam Ders</h3>
                <i class="fa fa-book fa-2x"></i>
                <b><?=@sayiformati($istatistik2['toplam'])?></b>
            </div>
            <div class="bilgi-kutu renk3">
                <h3>Toplam Duyuru</h3>
                <i class="fa fa-bullhorn fa-2x"></i>
                <b><?=@sayiformati($istatistik3['toplam'])?></b>
            </div>
            <div class="bilgi-kutu renk4">
                <h3>Toplam Etkinlik</h3>
                <i class="fa fa-hashtag fa-2x"></i>
                <b><?=@sayiformati($istatistik4['toplam'])?></b>
            </div>
        </div>
        <div class="temiz"></div>
        <div class="pano-menubox">
          <?php if($_SESSION['tip']=='1'){?>
          <a href="<?=$adres.'ders'?>" class="pano-menu">
              <i class="fa fa-book"></i>
              <h4>Dersler</h4>
          </a>
          <a href="<?=$adres.'ders/ekle'?>" class="pano-menu">
              <i class="fa fa-book"><i class="fa fa-plus"></i></i>
              <h4>Ders Ekle</h4>
          </a>
          <a href="<?=$adres.'sinav'?>" class="pano-menu">
              <i class="fa fa-pencil-square-o"></i>
              <h4>Sınavlar</h4>
          </a>
          <a href="<?=$adres.'sinav/ekle'?>" class="pano-menu">
              <i class="fa fa-pencil-square-o"><i class="fa fa-plus"></i></i>
              <h4>Sınav Ekle</h4>
          </a>
          <a href="<?=$adres.'duyuru'?>" class="pano-menu">
              <i class="fa fa-bullhorn"></i>
              <h4>Duyurular</h4>
          </a>
          <a href="<?=$adres.'duyuru/ekle'?>" class="pano-menu">
              <i class="fa fa-bullhorn"><i class="fa fa-plus"></i></i>
              <h4>Duyuru Ekle</h4>
          </a>
          <a href="<?=$adres.'etkinlik'?>" class="pano-menu">
              <i class="fa fa-hashtag"></i>
              <h4>Etkinlikler</h4>
          </a>
          <a href="<?=$adres.'etkinlik/ekle'?>" class="pano-menu">
              <i class="fa fa-hashtag"><i class="fa fa-plus"></i></i>
              <h4>Etkinlik Ekle</h4>
          </a>
          <a href="<?=$adres.'kullanici/ogrenci-ekle'?>" class="pano-menu">
              <i class="fa fa-user"><i class="fa fa-plus"></i></i>
              <h4>Öğrenci Ekle</h4>
          </a>
          <a href="<?=$adres.'kullanici/akdemisyen-ekle'?>" class="pano-menu">
              <i class="fa fa-user"><i class="fa fa-plus"></i></i>
              <h4>Akademisyen Ekle</h4>
          </a>
          <a href="<?=$adres.'profil'?>" class="pano-menu">
              <i class="fa fa-user"></i>
              <h4>Profil</h4>
          </a>
          <a href="<?=$adres.'profil/sifre'?>" class="pano-menu">
              <i class="fa fa-key"></i>
              <h4>Şifre Değiştir</h4>
          </a>
          <?php }?>
         <?php if($_SESSION['tip']=='2'){?>
          <a href="<?=$adres.'ders'?>" class="pano-menu">
              <i class="fa fa-book"></i>
              <h4>Dersler</h4>
          </a>
          <a href="<?=$adres.'sinav'?>" class="pano-menu">
              <i class="fa fa-pencil-square-o"></i>
              <h4>Sınavlar</h4>
          </a>
          <a href="<?=$adres.'duyuru'?>" class="pano-menu">
              <i class="fa fa-bullhorn"></i>
              <h4>Duyurular</h4>
          </a>
          <a href="<?=$adres.'etkinlik'?>" class="pano-menu">
              <i class="fa fa-hashtag"></i>
              <h4>Etkinlikler</h4>
          </a>
          <a href="<?=$adres.'profil'?>" class="pano-menu">
              <i class="fa fa-user"></i>
              <h4>Profil</h4>
          </a>
          <a href="<?=$adres.'profil/sifre'?>" class="pano-menu">
              <i class="fa fa-key"></i>
              <h4>Şifre Değiştir</h4>
          </a>
          <?php }?>
        </div>
<?php include'panelalt.php';?>
