<?php 
require_once'panelust.php';

@$sayfa = $_GET['sy'];

switch ($sayfa) {
	case 'ogrenci-ekle':
		include'include/kullanici-ogrenci-ekle.php';
		break;
	case 'akdemisyen-ekle':
		include'include/kullanici-akademisyen-ekle.php';
		break;
	default:
		include'include/kullanici-liste.php';
		break;
}

require_once'panelalt.php';
?>