<?php include'baglanti.php';
//SEO için link düzenlemeleri
class seo {
  function seocevir($str, $options = array())
    {
     $str = mb_convert_encoding((string)$str, 'UTF-8', mb_list_encodings());
     $defaults = array(
         'delimiter' => '-',
         'limit' => null,
         'lowercase' => true,
         'replacements' => array(),
         'transliterate' => true
     );
     $options = array_merge($defaults, $options);
     $char_map = array(
         // Türkçe
         'Ş' => 'S', 'İ' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'Ğ' => 'G',
         'ş' => 's', 'ı' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'ğ' => 'g',
         // Latin
         'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE', 'Ç' => 'C',
         'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I',
         'Ð' => 'D', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ő' => 'O',
         'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ű' => 'U', 'Ý' => 'Y', 'Þ' => 'TH',
         'ß' => 'ss',
         'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae', 'ç' => 'c',
         'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i',
         'ð' => 'd', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ő' => 'o',
         'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'ű' => 'u', 'ý' => 'y', 'þ' => 'th',
         'ÿ' => 'y',
         // Özel Karakterler
         '©' => '(c)', '&quot;' => '', '&#039;' => ''
     );
     $str = preg_replace(array_keys($options['replacements']), $options['replacements'], $str);
     if ($options['transliterate']) {
         $str = str_replace(array_keys($char_map), $char_map, $str);
     }
     $str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);
     $str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);
     $str = mb_substr($str, 0, ($options['limit'] ? $options['limit'] : mb_strlen($str, 'UTF-8')), 'UTF-8');
     $str = trim($str, $options['delimiter']);
     return $options['lowercase'] ? mb_strtolower($str, 'UTF-8') : $str;
   }
  #Tüm karakterler büyük harf oluyor
  function buyuk($str){
    return strtr($str, "abcçdefgğhıijklmnoöpqrsştuüvwxyz", "ABCÇDEFGĞHIİJKLMNOÖPQRSŞTUÜVWXYZ");
  }
  #Tüm karakterler küçük harf oluyor
  function kucuk($str){
    return strtr($str,"ABCÇDEFGĞHIİJKLMNOÖPQRSŞTUÜVWXYZ","abcçdefgğhıijklmnoöpqrsştuüvwxyz");
  }
  function bosluksil($metin) {
    return trim(preg_replace('/\s+/',' ',$metin));
  }
  function kucult($al) {
    return mb_strtolower($al,"UTF-8");
  }
  function buyult($al) {
    return mb_strtoupper($al,"UTF-8");
  }
  function tumbosluksil($s) {
    $s = explode(',',$s);
    foreach ($s as $k) {
    	$m[$k] = preg_replace('/\s+/','',$m[$k]);
    }
    return $m;
  }
}
//Binli sayıların arasına nokta koyuluyor.
function sayiformati($sayi) {$sonuc = number_format($sayi, 0,",",".");return $sonuc;}
//Gelen text içeriği HTML karakterleri pasifize ediliyor.
function suz($yazi) {$suzulen = htmlspecialchars($yazi, ENT_QUOTES, "UTF-8");return $suzulen;}
function gerisuz($yazi) {$suzulen = htmlspecialchars_decode($yazi);return $suzulen;}
//İfadelerinin arasına artı koyar
function artikoy($etiket) { return trim(preg_replace('/\s+/','+',$etiket));}
//Etiket Fonksiyonu
function etiket($icerik,$yollu){
	foreach (explode(",",$icerik) as $etiket){
		echo '<a style="display:inline-block;" href="'.$yollu.'tag/'.artikoy(trim($etiket)).'" title="'.$etiket.'">'.$etiket.'</a> ';
	}
}
#Zaman Sınıfı Tarih - Saat ve Saniye
class zaman {
	function tarih($date){# MYSQL TARİHİ TÜRKİYE TARİHİNE GÖRE AYARLARINYOR.
		$date = explode("-", $date);
		$gun  = substr($date[2],0,2);
		$ay   = $date[1];
		$yil  = $date[0];

		if( $ay == 1 || $ay == 01){$ay = "Ocak";}
		elseif( $ay == 2 || $ay == '02'){$ay = "Şubat";}
		elseif( $ay == 3 || $ay == '03'){$ay = "Mart";}
		elseif( $ay == 4 || $ay == '04'){$ay = "Nisan";}
		elseif( $ay == 5 || $ay == '05'){$ay = "Mayıs";}
		elseif( $ay == 6 || $ay == '06'){$ay = "Haziran";}
		elseif( $ay == 7 || $ay == '07'){$ay = "Temmuz";}
		elseif( $ay == 8 || $ay == '08'){$ay = "Ağustos";}
		elseif( $ay == 9 || $ay == '09'){$ay = "Eylül";}
		elseif( $ay == 10 ){$ay = "Ekim";}
		elseif( $ay == 11 ){$ay = "Kasım";}
		else{$ay = "Aralık";}

		$date = $gun." ".$ay." ".$yil;

		return $date;
	}
	function saat($date){
		$date = explode(":",$date);
		$saat = substr($date[0],-2);
		$dakika = $date[1];
		$saat = $saat.':'.$dakika;

		return $saat;
	}
	function saniye($date){
		$date = explode(":",$date);
		$saat = substr($date[0],-2);
		$dakika = $date[1];
		$saniye = $date[2];
		$saniye = $saat.':'.$dakika.':'.$saniye;

		return $saniye;
	}
  function tumzaman($date) {
    $tarih = $this->tarih($date);
    $saat  = $this->saat($date);

    return $tarih.' '.$saat;
  }
	function zamanbulucu($zaman){
		//Şimdiki zaman ile gönderilen zaman farkını bulma

		$fark = time() - strtotime($zaman);
		//farkın ne kadar süre yaptığını hesaplama
		$sn = $fark;
		$dk = round($fark/60);
		$saat = round($fark/(60*60));
		$gun = round($fark/(60*60*24));
		$hafta = round($fark/(60*60*24*7));
		$ay = round($fark/(60*60*24*7*30));
		$yil = round($fark/(60*60*24*7*30*12));

		//Farkın üzerinden ne kadar zaman geçtiğini bulma
		if($sn < 60){
			echo $sn.' saniye önce.';
		}elseif($dk < 60){
			return $dk.' dakika önce.';
		}elseif($saat < 24){
			return $saat.' saat önce.';
		}elseif($gun < 7){
			return $gun.' gün önce.';
		}elseif($hafta < 4){
			return $hafta.' hafta önce.';
		}elseif($ay < 12){
			return $this->tarih(date("Y-m-d",strtotime($zaman)));
		}else{
			return $this->tarih(date("Y-m-d",strtotime($zaman)));
		}
	}
  function webtarih($date){# Mysql tarihi inputa göre ayarlanıyor
		$date = explode("-", $date);
		$gun  = substr($date[2],0,2);
		$ay   = $date[1];
		$yil  = $date[0];

		return $date = $yil.'-'.$ay.'-'.$gun;
	}
  function webtarihsaat($date){# Mysql tarihi inputa göre ayarlanıyor
		$date = explode("-", $date);
    $saat = substr($date[2],3,5);
		$gun  = substr($date[2],0,2);
		$ay   = $date[1];
		$yil  = $date[0];

		return $date = $yil.'-'.$ay.'-'.$gun.'T'.$saat;
	}

}

#VERİLERİN KAÇ GÜNLÜK OLDUĞU HESAPLANIYOR...
function gunhesapla($tarih_gir){
    ///girilecek olan tarihimizin arasındaki "-" işaretinin olması lazım.Örnek olara 02-12-2006 gibi
    ///eğer başka bir kesme kullanacaksanız aşağıda explode satıtında bulunan "-" değiştirmeniz yeterli
    ///explode komutu ile tarihimizi parçalara ayırıp değişkenlere aktarıyoruz
	$yeni_tarih=explode("-",$tarih_gir);
	$ilk_gun=$yeni_tarih[2]; //üçüncü index yıl değerini alır.
	$ilk_ay=$yeni_tarih[1];  //ikinci index ay değerini alır.
	$ilk_yil=$yeni_tarih[0]; //ilk index gün değerini alır.
	$son_gun=date("d");
	$son_ay=date("m");
	$son_yil=date("Y");
	///burada aylarımızın kaç gün çektiğini değişkenlere aktarıyoruz.
	$ek[1]=31;
	$ek[2]=28;
	$ek[3]=31;
	$ek[4]=30;
	$ek[5]=31;
	$ek[6]=30;
	$ek[7]=31;
	$ek[8]=31;
	$ek[9]=30;
	$ek[10]=31;
	$ek[11]=30;
	$ek[12]=31;

	///önce yıl farkı varsa bundan doğan farkı GÜN olarak hesaplayalım

	$yil_fark=($son_yil-$ilk_yil) * 365 ;
	////for döngüsüyle ayları topluyorum
	for($i=1;$i<$son_ay;$i++){
	    @$son_ay_toplam=$son_ay_toplam+$ek[$i];
	}
	///şimdiki  gün ve ay  toplamımız
	$toplam_son_gun=$son_ay_toplam+$son_gun;
	////girilen ayı hesaplayalım
	for($m=1;$m<$ilk_ay;$m++){
	    @$ilk_ay_toplam=$ilk_ay_toplam+$ek[$m];
	}
	 ////girilen ay ve günü hesaplayalım
	$toplam_ilk_gun=$ilk_ay_toplam+$ilk_gun;
	$sonuc=$toplam_son_gun-$toplam_ilk_gun+$yil_fark;
	/////burada sonuc değişkenine sonucumuzu yükledik.
	/////artık kullanacağınız yere göre değişiklik yapabilirsiniz
	/////ben burada basit bir if deyimi ile eğer tarih bugünün tarihi ise bugün sisteme girmiş
	/////eğer tarih daha önce ise kaç gün fark varsa onu yazdırıyorum
     if($sonuc==0){
         $sonuc = 1;
     }else{
         $sonuc;
     }
	 return $sonuc;
}
////////GoogleRecaptcha Doğrulama Fonksiyonu
function getCurlData($url)
{
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_TIMEOUT, 10);
curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16");
$curlData = curl_exec($curl);
curl_close($curl);
return $curlData;
}
//Site Ayar Çekme Fonksiyonu
function ayar($ayaradi) {
	global $db;
	$veri = $db->prepare("SELECT * FROM tb_ayar WHERE ayar_adi = :ayaradi");
	$veri->execute([':ayaradi'=>$ayaradi]);
	$dizi=$veri->fetch(PDO::FETCH_ASSOC);
  return $dizi['ayar_deger'];
}
//Site Kategori Fonksiyonu
function kategori($veri, $ust_id = 0, $kategori_id = null) {

    $r = array();
    $a = array();
    $html = '';
    foreach ($veri as $d) {
        if ($d['kategori_id'] == $ust_id)
            $a[] = $d;
    }
    foreach ($a as $kategori) {
        $html .= kategori($veri, $kategori['grup']);
        $html .= $kategori['kategori'];
        $html .= ' > ';
        if ($kategori_id) {
            foreach ($veri as $s) {
                if ($s['kategori_id'] == $kategori_id)
                    $r[] = $s;
            }
            foreach ($r as $re) {
                $html .= $re['kategori'];
            }
        }
    }
    return $html;
}
//Yazı Linkleme Fonksiyonu
function yazilink($tur,$yol,$id,$adres) {
  if($tur=='1') {//Makale Linki
    $yazilink = $adres.'makale/'.$yol.'-'.$id;
  }
  if($tur=='2') {//Video Blog Linki
    $yazilink = $adres.'video/'.$yol.'-'.$id;
  }
  if($tur=='3') {//Faaliyet Alanı Linki
    $yazilink = $adres.'faaliyet-alani/'.$yol.'-'.$id;
  }
  return $yazilink;
}
?>
