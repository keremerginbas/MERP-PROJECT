<?php
try {
	$db= new PDO("mysql:host=localhost;dbname=merp;charset=utf8",'root','');
	$db->exec("SET NAMES 'utf8'; SET CHARSET 'utf8'");
}
catch (PDOExpception $sorun) {
	echo $sorun->getMessage();
}
?>
