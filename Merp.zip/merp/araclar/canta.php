<?php
/*----------------------------Kpanel Sınıfları ve Fonksiyonları-----------------*/
//SEO için link düzenlemeleri
class seo {
  function seocevir($str, $options = array())
    {
     $str = mb_convert_encoding((string)$str, 'UTF-8', mb_list_encodings());
     $defaults = array(
         'delimiter' => '-',
         'limit' => null,
         'lowercase' => true,
         'replacements' => array(),
         'transliterate' => true
     );
     $options = array_merge($defaults, $options);
     $char_map = array(
         // Türkçe
         'Ş' => 'S', 'İ' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'Ğ' => 'G',
         'ş' => 's', 'ı' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'ğ' => 'g',
         // Latin
         'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE', 'Ç' => 'C',
         'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I',
         'Ð' => 'D', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ő' => 'O',
         'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ű' => 'U', 'Ý' => 'Y', 'Þ' => 'TH',
         'ß' => 'ss',
         'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae', 'ç' => 'c',
         'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i',
         'ð' => 'd', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ő' => 'o',
         'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'ű' => 'u', 'ý' => 'y', 'þ' => 'th',
         'ÿ' => 'y',
         // Özel Karakterler
         '©' => '(c)', '&quot;' => '', '&#039;' => ''
     );
     $str = preg_replace(array_keys($options['replacements']), $options['replacements'], $str);
     if ($options['transliterate']) {
         $str = str_replace(array_keys($char_map), $char_map, $str);
     }
     $str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);
     $str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);
     $str = mb_substr($str, 0, ($options['limit'] ? $options['limit'] : mb_strlen($str, 'UTF-8')), 'UTF-8');
     $str = trim($str, $options['delimiter']);
     return $options['lowercase'] ? mb_strtolower($str, 'UTF-8') : $str;
   }
  #Tüm karakterler büyük harf oluyor
  function buyuk($str){
    return strtr($str, "abcçdefgğhıijklmnoöpqrsştuüvwxyz", "ABCÇDEFGĞHIİJKLMNOÖPQRSŞTUÜVWXYZ");
  }
  #Tüm karakterler küçük harf oluyor
  function kucuk($str){
    return strtr($str,"ABCÇDEFGĞHIİJKLMNOÖPQRSŞTUÜVWXYZ","abcçdefgğhıijklmnoöpqrsştuüvwxyz");
  }
  function bosluksil($metin) {
    return trim(preg_replace('/\s+/',' ',$metin));
  }
  function kucult($al) {
    return mb_strtolower($al,"UTF-8");
  }
  function buyult($al) {
    return mb_strtoupper($al,"UTF-8");
  }
  function tumbosluksil($s) {
    $s = explode(',',$s);
    foreach ($s as $k) {
    	$m[$k] = preg_replace('/\s+/','',$m[$k]);
    }
    return $m;
  }
}
//Binli sayıların arasına nokta koyuluyor.
function sayiformati($sayi) {$sonuc = number_format($sayi, 0,",",".");return $sonuc;}
//Gelen text içeriği HTML karakterleri pasifize ediliyor.
function suz($yazi) {$suzulen = htmlspecialchars($yazi, ENT_QUOTES, "UTF-8");return $suzulen;}
function gerisuz($yazi) {$suzulen = htmlspecialchars_decode($yazi);return $suzulen;}
//İfadelerinin arasına artı koyar
function artikoy($etiket) { return trim(preg_replace('/\s+/','+',$etiket));}
//Etiket Fonksiyonu
function etiket($icerik,$yollu){
	foreach (explode(",",$icerik) as $etiket){
		echo '<a style="display:inline-block;" href="'.$yollu.'tag/'.artikoy(trim($etiket)).'" title="'.$etiket.'">'.$etiket.'</a> ';
	}
}
#Kullanıcı Girişi
function giris($kullanici,$sifre,$zaman,$adres) {
	if(isset($_SESSION['cikis'])) {
		$oturum=time()-$_SESSION['cikis'];
		if($oturum > $zaman) {
			unset($_SESSION['cikis']);
			header("Location:".$adres."giris");
			exit();
		}else {
			if(empty($kullanici) && $sifre!=='giris'){
				session_destroy();
				header("Location:".$adres."index.php");
			}
		}
	}else {
		session_destroy();
		header("Location:".$adres."index.php");
	}
}

#Şifre Sorgulama
function sifre($sifreal) {
	$sifre = md5(md5(md5($sifreal)));
	return $sifre;
}


#E-Posta Gönderme Fonksiyonu
function mailgonder($gonderilen,$baslik,$icerik) {
	global $db;

	$eposta   = ayar('eposta');
	$sifre    = ayar('sifre');
	$sunucu   = ayar('stmp');
	$port     = ayar('port');
	$site     = ayar('title');

	require_once'araclar/mail/class.phpmailer.php';
	$mail = new PHPMailer();

	$mail->IsSMTP();
	$mail->SetLanguage("tr", "mail/language");
	//$mail->SMTPSecure = 'ssl';
	$mail->Host       = $sunucu;
	$mail->SMTPAuth   = true;
	$mail->Username   = $eposta;
	$mail->Password   = $sifre;
	$mail->Port       = $port;

	$mail->From     = $eposta;
	$mail->FromName = $site;
	$mail->CharSet  = "UTF-8";
	$mail->IsHTML(true);

	$mail->AddAddress("$gonderilen");
	$mail->Subject     = "$baslik";
	$mail->Body        = "$icerik";

	if($mail->Send()) return true; else echo $mail->ErrorInfo;
}

#Yetkilendirme Menü Fonksiyonu
function menual($menu) {
	global $db;

	$yetkial = $db->query("SELECT * FROM tb_yetki,tb_yetkisayfa WHERE tb_yetki.sayfa_id = tb_yetkisayfa.sayfa_id && kullanici_id=".$_SESSION['user']." && tb_yetkisayfa.sayfa LIKE '".$menu."'");
	$sonuc = $yetkial->rowCount();
	return $sonuc;
}

function ayarguncelle($ayardeger,$ayaradi) {
	global $db;

	$guncelle = "UPDATE tb_ayar SET ayar_deger = :ayardeger WHERE ayar_adi = :ayaradi";
	$guncel = $db->prepare($guncelle);
	$guncel->execute(array(':ayardeger'=>$ayardeger, ':ayaradi'=>$ayaradi));
}
//Site Ayar Çekme Fonksiyonu
function ayar($ayaradi) {
	global $db;
	$veri = $db->prepare("SELECT * FROM tb_ayar WHERE ayar_adi = :ayaradi");
	$veri->execute([':ayaradi'=>$ayaradi]);
	$dizi=$veri->fetch(PDO::FETCH_ASSOC);
  return @$dizi['ayar_deger'];
}

#Zaman Sınıfı Tarih - Saat ve Saniye
class zaman {
	function tarih($date){# MYSQL TARİHİ TÜRKİYE TARİHİNE GÖRE AYARLARINYOR.
		$date = explode("-", $date);
		$gun  = substr($date[2],0,2);
		$ay   = $date[1];
		$yil  = $date[0];

		if( $ay == 1 || $ay == 01){$ay = "Ocak";}
		elseif( $ay == 2 || $ay == '02'){$ay = "Şubat";}
		elseif( $ay == 3 || $ay == '03'){$ay = "Mart";}
		elseif( $ay == 4 || $ay == '04'){$ay = "Nisan";}
		elseif( $ay == 5 || $ay == '05'){$ay = "Mayıs";}
		elseif( $ay == 6 || $ay == '06'){$ay = "Haziran";}
		elseif( $ay == 7 || $ay == '07'){$ay = "Temmuz";}
		elseif( $ay == 8 || $ay == '08'){$ay = "Ağustos";}
		elseif( $ay == 9 || $ay == '09'){$ay = "Eylül";}
		elseif( $ay == 10 ){$ay = "Ekim";}
		elseif( $ay == 11 ){$ay = "Kasım";}
		else{$ay = "Aralık";}

		$date = $gun." ".$ay." ".$yil;

		return $date;
	}
	function saat($date){
		$date = explode(":",$date);
		$saat = substr($date[0],-2);
		$dakika = $date[1];
		$saat = $saat.':'.$dakika;

		return $saat;
	}
	function saniye($date){
		$date = explode(":",$date);
		$saat = substr($date[0],-2);
		$dakika = $date[1];
		$saniye = $date[2];
		$saniye = $saat.':'.$dakika.':'.$saniye;

		return $saniye;
	}
  function tumzaman($date) {
    $tarih = $this->tarih($date);
    $saat  = $this->saat($date);

    return $tarih.' '.$saat;
  }
	function zamanbulucu($zaman){
		//Şimdiki zaman ile gönderilen zaman farkını bulma

		$fark = time() - strtotime($zaman);
		//farkın ne kadar süre yaptığını hesaplama
		$sn = $fark;
		$dk = round($fark/60);
		$saat = round($fark/(60*60));
		$gun = round($fark/(60*60*24));
		$hafta = round($fark/(60*60*24*7));
		$ay = round($fark/(60*60*24*7*30));
		$yil = round($fark/(60*60*24*7*30*12));

		//Farkın üzerinden ne kadar zaman geçtiğini bulma
		if($sn < 60){
			echo $sn.' saniye önce.';
		}elseif($dk < 60){
			return $dk.' dakika önce.';
		}elseif($saat < 24){
			return $saat.' saat önce.';
		}elseif($gun < 7){
			return $gun.' gün önce.';
		}elseif($hafta < 4){
			return $hafta.' hafta önce.';
		}elseif($ay < 12){
			return $this->tarih(date("Y-m-d",strtotime($zaman)));
		}else{
			return $this->tarih(date("Y-m-d",strtotime($zaman)));
		}
	}
  function webtarih($date){# Mysql tarihi inputa göre ayarlanıyor
		$date = explode("-", $date);
		$gun  = substr($date[2],0,2);
		$ay   = $date[1];
		$yil  = $date[0];

		return $date = $yil.'-'.$ay.'-'.$gun;
	}
  function webtarihsaat($date){# Mysql tarihi inputa göre ayarlanıyor
		$date = explode("-", $date);
    $saat = substr($date[2],3,5);
		$gun  = substr($date[2],0,2);
		$ay   = $date[1];
		$yil  = $date[0];

		return $date = $yil.'-'.$ay.'-'.$gun.'T'.$saat;
	}

}

?>
