<?php
session_start();
if(@$_GET['cikis']=="cik") {
	session_destroy();
	header("Location:index.php");
}else {
	header("Location:index.php");
}
?>