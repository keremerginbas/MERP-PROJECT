<?php 
require_once'panelust.php';

@$sayfa = $_GET['sy'];

switch ($sayfa) {
	case 'sifre':
		include'include/profil-sifre.php';
		break;
	default:
		include'include/profil-duzenle.php';
		break;
}

require_once'panelalt.php';
?>