<?php
include'panelust.php';
$id = (int) $_GET['p'];
if($_SESSION['user'] != $id) {header("Location:parola.php?p=".$_SESSION['user']);}
$kullanicial = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id=$id");
$sql 		 = $kullanicial->fetch(PDO::FETCH_ASSOC);

if(@$_POST['kaydet']) {
	$esifre  = $_POST['esifre'];
	$ysifre1 = $_POST['ysifre1'];
	$ysifre2 = $_POST['ysifre2'];

	if($sql['sifre'] == sifre($esifre)) {
		if(!empty($ysifre1) || !empty($ysifre2)) {
			if($ysifre1 == $ysifre2) {

				$sifre   = sifre($ysifre1);
            	$duzenle = $db->exec("UPDATE tb_kullanici SET sifre='$sifre' WHERE kullanici_id=$id");
				
				$mesaj   = 'Tebrikler şifreniz güncellendi.';
				$durum   = 'dogru';
		
			}else {
				$mesaj   = 'Yeni şifreler aynı değil.';
				$durum   = 'hata';
				$renk[1] = $hatarenk;
				$renk[2] = $hatarenk;							
			}
		}else {
			$mesaj   = 'Yeni şifre alanlarını eksiksiz doldurun.';
			$durum   = 'hata';
			$renk[1] = $hatarenk;
			$renk[2] = $hatarenk;
		}
	}else {
		$mesaj   = 'Eski şifrenizi hatalı girdiniz.';
		$durum   = 'hata';
		$renk[0] = $hatarenk;
	}
}

$kullanicial = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id=$id");
$sql 		 = $kullanicial->fetch(PDO::FETCH_ASSOC);

if($kullanicial->rowCount() == 0) {header("Location:kullanicilar.php");}//Kullanıcı yok yönlendirme
?>
<div class="genel-baslik">
	<h1>Profil</h1>  
    <a class="ustdizin" href="kullanicilar.php"><i class="fa fa-level-up"></i> Üst Dizin</a>
</div>
<div class="profil-ozet">
	<i class="fa fa-user"></i><?=!empty($sql['foto'])?'<img src="'.$sql['foto'].'" alt="profil" />':'';?>
    <div>
    	<span><?=$sql['adi']?></span>
        <b><?=$sql['eposta']?></b>
        <i><?=$sql['kullanici']?></i>
    </div>
</div>
<div class="ekleme profil">
	<form action="<?=$_SERVER['REQUEST_URI']?>" method="post"  enctype="multipart/form-data">
    	<ol>
        	<li>
            	<label>Eski Şifre</label>
                <input type="password" name="esifre" maxlength="25" required <?=@$renk[0]?>>
                <i></i>
			</li>
            <div class="b2">
            <li>
            	<label>Yeni Şifre</label>
                <input type="password" name="ysifre1" maxlength="25" required <?=@$renk[1]?>>
                <i></i>
			</li>
            <li>
            	<label>Yeni Şifre Terar</label>
                <input type="password" name="ysifre2" maxlength="25" required <?=@$renk[2]?>>
                <i></i>
			</li>
            </div>
        </ol>
        <div class="temiz"></div>
        <div class="bilgi <?=@$durum?>"><?=@$mesaj?></div>       
        <input type="submit" name="kaydet" value="ŞiFREYİ DEĞİŞTİR">
	</form> 
</div>
<?php include'panelalt.php'?>