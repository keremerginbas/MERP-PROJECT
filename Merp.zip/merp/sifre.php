<?php
ob_start();
session_start();
include'../araclar/baglanti.php';
include'../araclar/canta.php';
include'araclar/canta.php';

if(!empty($_SESSION['cikis'])) { header("Location:kpanel/pano");}//Direk bu sayfaya girilir ise panoya yönlenecek

if(@$_POST['gonder']) {
	$eposta = $_POST['login'];

	$mailkontrol = $db->query("SELECT * FROM tb_kullanici WHERE eposta='$eposta'");
	if($mailkontrol->rowCount() == '1') {
		$sifre  = substr(md5(rand(0,9999)), 8, 6);
		$sifre1 = sifre($sifre);
		$db->query("UPDATE tb_kullanici SET sifre='$sifre1' WHERE eposta='$eposta'");

		$icerik = '
		<table align="center" width="500" height="350" style="box-shadow:0 0 5px rgba(0,0,0,.25);" cellpadding="0" cellspacing="0">
			<tr>
				<td height="75" bgcolor="#03A9F4">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="'.ayar('dizin').'kpanel/images/logo.png" />
				<td>
			</tr>
			<tr>
				<td>
					<h1 style="font:bold 20px Arial;color:#666;width:100%;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kpanel Şifre Yenileme İşlemi</h1>
					<p style="font:normal 14px Arial;color:#999;text-align:center;line-height:20px;">Değerli kullanıcımız yapmış olduğunuz şifre yenileme işlemi<br/> başarılı bir şekilde gerçekleşmiştir.</p>
					<p style="font:bold 24px Arial;color:rgba(3,169,244,1);text-align:center;">'.$sifre.'</p>
					<p style="font:normal 14px Arial;color:#999;text-align:center;line-height:20px;">Yukarıda bulunan şifre ile panele giriş yapabilirsiniz.<br/><span style="color:#444;">Lütfen şifreyi daha sonra güncellemeyi unutmayınız !</span></p>
				</td>
			</tr>
		</table>';
		mailgonder($eposta,'Kpanel Şifre Yenileme',$icerik);

		$mesaj  = '<div class="bilgi dogru">Yeni parolanız E-Posta adresinize gönderildi</div>';
		$git    = '<a href="index.php">Kpanele giriş yap</a>';
		$eposta = '';
		session_destroy();

	}else {
		$mesaj  = '<div class="bilgi">Böyle bir E-Posta bulunamadı</div>';
		$renk 	= 'style="border-color:#C00;"';
	}
}
?>
<!--Bismillahirrahmanirrahim-->
<!doctype html>
<html lang="tr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/giris.css" />
<link rel="stylesheet" href="css/font-awesome.min.css" />
<link href="images/favicon.png" rel="shortcut icon" />

<title>Kpanel Şifremi Unuttum</title>
</head>
<body>
<div class="giris">
  <div class="baslik"></div>
  <form class="form" method="post">
    <span>
      <input type="email" placeholder="E-Posta Adresi" name="login" required <?=@$renk?> autofocus>
      <i class="fa fa-envelope"></i>
    </span>
    <div class="temiz"></div>
    <?=@$git?>
    <?=@$mesaj?>
    <input type="submit" name="gonder" value="PAROLAMI GÖNDER" />
  </form>
</div>
</body>
</html>
<?php ob_end_flush();?>
