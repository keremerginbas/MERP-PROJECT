<?php
ob_start();
session_start();

include('araclar/baglanti.php');
include('araclar/canta.php');

if(@$_GET['g']) {session_destroy();header("Location:kpanel/index.php");}//Farklı bir giriş tüm sessionlar siliniyor.

if(isset($_SESSION['cikis']) || isset($_SESSION['cikis2'])) { header("Location:".$_SESSION['sonlink']."");}//Direk bu sayfaya girilir ise panoya yönlenecek
if(empty($_SESSION['adi']) && empty($_SESSION['foto']) || !isset($_SESSION['adi'])) { header("Location:kpanel/index.php");}//adi ve foto sessionu yok ise index e gidecek

if(@$_POST['giris'])
{
	$sifre = sifre($_POST['sifre']);
	$oturum = @$_POST['oturum'];
  $sorgu = $db->query("SELECT * FROM tb_kullanici WHERE kullanici_id='".$_SESSION['user']."' && sifre='$sifre'");
  $sonuc = $sorgu->rowCount();

  if ($sonuc == 1) {
		$_SESSION['cikis'] = time();
		header("Location:".$_SESSION['sonlink']."");
		if(!empty($oturum)) { $_SESSION['cikis2'] = 86400;}
	}
	else
	 {
		$mesaj  = '<div class="bilgi">Parolayı yanlış girdiniz</div>';
		$renk 	= 'style="border-color:#C00;"';
	 }
}

?>
<!--Bismillahirrahmanirrahim-->
<!doctype html>
<html lang="tr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/giris.css" />
<link rel="stylesheet" href="css/font-awesome.min.css" />
<link href="images/favicon.png" rel="shortcut icon" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>MERP Öğrenci Yönetim Sistemi</title>
</head>
<body>
<div class="giris">
  <div class="kullanici">
    <img src="<?=$_SESSION['foto']?>" />
    <span><?=$_SESSION['adi']?></span>
  </div>
  <form class="form" method="post">
    <span>
      <input type="password" placeholder="Parola" name="sifre" <?=@$renk?> autofocus>
      <i class="fa fa-lock"></i>
    </span>
    <div class="temiz"></div>
    <input type="checkbox" name="oturum" id="oturum">
    <label for="oturum">Oturumu açık tut</label>
    <a class="sag" href="giris.php?g=1">Farklı hesap ile gir</a>
    <div class="temiz"></div>
    <?=@$mesaj?>
    <input type="submit" name="giris" value="GİRİŞ YAP" >
  </form>
</div>
</body>
</html>
<?php ob_end_flush(); ?>
